# Curiosidades Remotion
1. `bash setup.sh`  (una vez)
2. `npm run studio`  -> vista previa (puerto 3000)
3. Edita `data/video.json` con tu guion
4. `npm run make`  -> voz + MP4 en `out/video.mp4`
Sin Codespaces: Actions > "Render video" > Run workflow > descarga el artefacto `video-mp4`.
