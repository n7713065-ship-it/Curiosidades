import React, {ReactNode} from "react";
import {AbsoluteFill, Audio, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {loadFont} from "@remotion/google-fonts/Poppins";
import {PALETTES, SceneData, T, Word} from "./config";

export const {fontFamily} = loadFont("normal", {weights: ["800"], subsets: ["latin", "latin-ext"]});

export const Captions: React.FC<{words: Word[]; offset: number}> = ({words, offset}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = (frame - offset) / fps;
  if (!words.length || t < 0) return null;
  const groups: Word[][] = [];
  for (let i = 0; i < words.length; i += 3) groups.push(words.slice(i, i + 3));
  let gi = groups.findIndex((g) => t <= g[g.length - 1].end + 0.1);
  if (gi < 0) gi = groups.length - 1;
  return (
    <div style={{position: "absolute", left: 60, right: 60, bottom: 340, display: "flex", flexWrap: "wrap", justifyContent: "center", gap: "10px 22px"}}>
      {groups[gi].map((w, k) => {
        const active = t >= w.start && t <= w.end + 0.05;
        const sp = spring({frame: frame - offset - Math.round(w.start * fps), fps, config: {damping: 12, stiffness: 200}});
        return (
          <span key={k} style={{
            fontFamily, fontSize: 92, fontWeight: 800, textTransform: "uppercase",
            color: active ? "#facc15" : "#fff",
            transform: `scale(${active ? 1 + 0.15 * sp : 1})`,
            WebkitTextStroke: "10px #000", paintOrder: "stroke fill",
            textShadow: "0 8px 0 rgba(0,0,0,.5)",
          }}>{w.text}</span>
        );
      })}
    </div>
  );
};

export const Shell: React.FC<{i: number; s: SceneData; children: ReactNode}> = ({i, s, children}) => {
  const frame = useCurrentFrame();
  const p = PALETTES[i % PALETTES.length];
  return (
    <AbsoluteFill style={{background: `linear-gradient(${160 + frame * 0.3}deg, ${p[0]}, #000)`, fontFamily}}>
      {[0, 1, 2, 3, 4].map((n) => {
        const x = 540 + Math.sin(frame / 40 + n * 1.7) * 420;
        const y = 960 + Math.cos(frame / 50 + n * 2.3) * 700;
        const r = 160 + n * 50;
        return <div key={n} style={{position: "absolute", left: x - r, top: y - r, width: r * 2, height: r * 2, borderRadius: "50%", background: p[1 + (n % 2)], opacity: 0.14, filter: "blur(30px)"}} />;
      })}
      <AbsoluteFill style={{opacity: 0.08, backgroundImage: "linear-gradient(#fff 2px,transparent 2px),linear-gradient(90deg,#fff 2px,transparent 2px)", backgroundSize: "90px 90px", backgroundPosition: `0px ${frame * 2}px`}} />
      {children}
      {s.audio && <Sequence from={T / 2}><Audio src={staticFile(s.audio)} /></Sequence>}
      <Sequence durationInFrames={30}><Audio src={staticFile("sfx/whoosh.wav")} volume={0.35} /></Sequence>
      <Captions words={s.words} offset={T / 2} />
    </AbsoluteFill>
  );
};
