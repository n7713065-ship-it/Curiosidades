import React from "react";
import {AbsoluteFill, Audio, staticFile} from "remotion";
import {linearTiming, TransitionSeries} from "@remotion/transitions";
import {slide} from "@remotion/transitions/slide";
import {wipe} from "@remotion/transitions/wipe";
import {flip} from "@remotion/transitions/flip";
import {fade} from "@remotion/transitions/fade";
import {sceneFrames, T, VideoProps} from "./config";
import {Fact, Globe, Hook, Stat} from "./scenes";

const transitions: any[] = [slide({direction: "from-bottom"}), wipe({direction: "from-left"}), flip({direction: "from-right"}), fade()];

export const Video: React.FC<VideoProps> = ({scenes, music}) => {
  if (!scenes.length) return <AbsoluteFill style={{background: "#000"}} />;
  return (
    <AbsoluteFill style={{background: "#000"}}>
      {music && <Audio src={staticFile(music)} volume={0.14} loop />}
      <TransitionSeries>
        {scenes.flatMap((s, i) => {
          const C = s.type === "hook" ? Hook : s.type === "stat" ? Stat : s.type === "globe" ? Globe : Fact;
          const items = [
            <TransitionSeries.Sequence key={`s${i}`} durationInFrames={sceneFrames(s)}>
              <C s={s} i={i} />
            </TransitionSeries.Sequence>,
          ];
          if (i < scenes.length - 1) {
            items.push(<TransitionSeries.Transition key={`t${i}`} presentation={transitions[i % transitions.length]} timing={linearTiming({durationInFrames: T})} />);
          }
          return items;
        })}
      </TransitionSeries>
    </AbsoluteFill>
  );
};
