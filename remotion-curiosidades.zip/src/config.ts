export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const T = 12; // frames de transición
export type Word = {text: string; start: number; end: number};
export type SceneData = {
  type: "hook" | "fact" | "stat" | "globe" | "outro";
  title: string; text: string; emoji?: string;
  value?: number; suffix?: string; label?: string;
  audio: string | null; duration: number; words: Word[];
};
export type VideoProps = {title: string; music: string | null; scenes: SceneData[]};
export const sceneFrames = (s: SceneData) => Math.round(s.duration * FPS) + T;
export const totalFrames = (sc: SceneData[]) => sc.reduce((a, s) => a + sceneFrames(s), 0) - T * (sc.length - 1);
export const PALETTES = [
  ["#0f172a", "#6366f1", "#22d3ee"],
  ["#1e1b4b", "#ec4899", "#facc15"],
  ["#052e16", "#22c55e", "#a3e635"],
  ["#431407", "#f97316", "#fde047"],
];
