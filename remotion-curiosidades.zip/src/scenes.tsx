import React from "react";
import {AbsoluteFill, Audio, Easing, interpolate, random, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {ThreeCanvas} from "@remotion/three";
import {PALETTES, SceneData} from "./config";
import {Shell} from "./ui";

type P = {s: SceneData; i: number};
const box: React.CSSProperties = {position: "absolute", left: 60, right: 60, top: 160, height: 1100, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center"};
const title: React.CSSProperties = {fontSize: 100, fontWeight: 800, color: "#fff", lineHeight: 1.1, textShadow: "0 10px 30px rgba(0,0,0,.6)"};

export const Hook: React.FC<P> = ({s, i}) => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig(); const p = PALETTES[i % 4];
  const em = spring({frame: f - 2, fps, config: {damping: 8}});
  return (
    <Shell i={i} s={s}>
      <div style={box}>
        <div style={{fontSize: 280, transform: `scale(${em}) rotate(${Math.sin(f / 10) * 8}deg)`}}>{s.emoji}</div>
        <div style={{...title, fontSize: 112, marginTop: 40}}>
          {s.title.split(" ").map((w, k) => {
            const sp = spring({frame: f - 8 - k * 4, fps, config: {damping: 10, stiffness: 120}});
            return <span key={k} style={{display: "inline-block", margin: "0 14px", opacity: sp, transform: `translateY(${(1 - sp) * 120}px) scale(${0.6 + 0.4 * sp})`, color: k % 3 === 1 ? p[2] : "#fff"}}>{w}</span>;
          })}
        </div>
      </div>
    </Shell>
  );
};

export const Fact: React.FC<P> = ({s, i}) => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig(); const p = PALETTES[i % 4];
  const card = spring({frame: f - 2, fps, config: {damping: 14}});
  const bar = interpolate(f, [10, 40], [0, 100], {extrapolateRight: "clamp", easing: Easing.out(Easing.cubic)});
  return (
    <Shell i={i} s={s}>
      <div style={box}>
        <svg width="620" height="620" viewBox="0 0 100 100" style={{position: "absolute", top: 20, transform: `rotate(${f * 1.2}deg)`, opacity: 0.5}}>
          <circle cx="50" cy="50" r="46" fill="none" stroke={p[2]} strokeWidth="1.2" strokeDasharray="8 6" />
          <circle cx="50" cy="50" r="38" fill="none" stroke={p[1]} strokeWidth="2" strokeDasharray="30 12" />
        </svg>
        <div style={{fontSize: 320, transform: `translateY(${Math.sin(f / 12) * 25}px) scale(${card})`, marginTop: -120}}>{s.emoji}</div>
        <div style={{...title, marginTop: 70, transform: `translateX(${(1 - card) * -700}px)`}}>{s.title}</div>
        <div style={{height: 14, width: `${bar * 6}px`, background: p[2], borderRadius: 7, marginTop: 30}} />
      </div>
    </Shell>
  );
};

export const Stat: React.FC<P> = ({s, i}) => {
  const f = useCurrentFrame(); const {fps} = useVideoConfig(); const p = PALETTES[i % 4];
  const v = interpolate(f, [10, 75], [0, s.value ?? 0], {extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.out(Easing.cubic)});
  const pop = spring({frame: f - 75, fps, config: {damping: 6}});
  return (
    <Shell i={i} s={s}>
      <Sequence from={75}><Audio src={staticFile("sfx/pop.wav")} volume={0.5} /></Sequence>
      <div style={box}>
        <div style={{...title, fontSize: 80, color: p[2]}}>{s.title}</div>
        <div style={{fontSize: 260, fontWeight: 800, color: "#fff", transform: `scale(${1 + pop * 0.12})`, textShadow: `0 0 60px ${p[1]}`}}>
          {Math.round(v).toLocaleString("es-MX")}<span style={{fontSize: 100}}>{s.suffix}</span>
        </div>
        <div style={{display: "flex", alignItems: "flex-end", gap: 24, height: 260, marginTop: 40}}>
          {[0.4, 0.65, 0.5, 0.85, 1].map((h, k) => {
            const g = spring({frame: f - 10 - k * 5, fps, config: {damping: 14}});
            return <div key={k} style={{width: 90, height: 260 * h * g, borderRadius: 18, background: k === 4 ? p[2] : p[1]}} />;
          })}
        </div>
        <div style={{...title, fontSize: 64, marginTop: 40, opacity: 0.9}}>{s.label}</div>
      </div>
    </Shell>
  );
};

export const Globe: React.FC<P> = ({s, i}) => {
  const f = useCurrentFrame(); const {fps, width, height} = useVideoConfig(); const p = PALETTES[i % 4];
  const sc = spring({frame: f, fps, config: {damping: 12}});
  return (
    <Shell i={i} s={s}>
      <ThreeCanvas width={width} height={height} camera={{position: [0, 0, 8], fov: 45}} style={{position: "absolute", inset: 0}}>
        <ambientLight intensity={0.6} />
        <pointLight position={[10, 10, 10]} intensity={200} />
        <group position={[0, 1.2, 0]} scale={sc}>
          <group rotation={[0.3, f * 0.02, 0]}>
            <mesh><sphereGeometry args={[2, 48, 48]} /><meshStandardMaterial color={p[1]} roughness={0.5} /></mesh>
            <mesh><sphereGeometry args={[2.04, 24, 24]} /><meshBasicMaterial color={p[2]} wireframe transparent opacity={0.35} /></mesh>
          </group>
          <mesh rotation={[1.2, 0.2, f * 0.01]}><torusGeometry args={[3.2, 0.05, 16, 100]} /><meshBasicMaterial color={p[2]} /></mesh>
        </group>
        {Array.from({length: 40}).map((_, k) => (
          <mesh key={k} position={[(random(`x${k}`) - 0.5) * 14, (random(`y${k}`) - 0.5) * 20, -4 - random(`z${k}`) * 4]}>
            <sphereGeometry args={[0.05 + random(`r${k}`) * 0.07, 8, 8]} /><meshBasicMaterial color="#fff" />
          </mesh>
        ))}
      </ThreeCanvas>
      <div style={{...box, top: 1000, height: 250}}><div style={{...title, fontSize: 90, opacity: sc}}>{s.title}</div></div>
    </Shell>
  );
};
