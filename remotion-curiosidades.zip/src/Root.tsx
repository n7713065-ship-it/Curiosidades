import React from "react";
import {Composition, staticFile} from "remotion";
import {Video} from "./Video";
import {FPS, H, W, totalFrames, VideoProps} from "./config";

export const Root: React.FC = () => (
  <Composition
    id="Curiosidad"
    component={Video}
    width={W}
    height={H}
    fps={FPS}
    durationInFrames={900}
    defaultProps={{title: "", music: null, scenes: []} as VideoProps}
    calculateMetadata={async () => {
      const p = (await (await fetch(staticFile("timeline.json"))).json()) as VideoProps;
      return {durationInFrames: Math.max(totalFrames(p.scenes), 1), props: p};
    }}
  />
);
