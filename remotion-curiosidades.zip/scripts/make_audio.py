"""Genera música ambiental y efectos propios (libres de derechos)."""
import wave, math, random, struct, pathlib
OUT = pathlib.Path(__file__).resolve().parent.parent / "public"
SR = 22050

def save(name, samples):
    with wave.open(str(OUT / name), "w") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 32000)) for s in samples))

def note(f): return 440 * 2 ** ((f - 69) / 12)

# Música: Am - F - C - G, pad suave + arpegio
chords = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]]
seg = 4.0
music = []
for rep in range(2):
    for ch in chords:
        n = int(SR * seg)
        for k in range(n):
            t = k / SR
            env = min(1, t / 0.8) * min(1, (seg - t) / 0.8)
            v = sum(math.sin(2 * math.pi * note(m) * t) + 0.3 * math.sin(4 * math.pi * note(m) * t) for m in ch) / 5
            beat = t % 0.5
            arp = note(ch[int(t / 0.5) % 3] + 12)
            v += 0.35 * math.sin(2 * math.pi * arp * t) * math.exp(-beat * 7)
            music.append(v * env * 0.5)
save("music.wav", music)

(OUT / "sfx").mkdir(exist_ok=True)
# Whoosh
random.seed(1); n = int(SR * 0.6); lp = 0; w = []
for k in range(n):
    t = k / n
    a = 0.05 + 0.9 * t
    lp += (random.uniform(-1, 1) - lp) * a
    w.append(lp * math.sin(math.pi * t) * 1.6)
w and save("sfx/whoosh.wav", w)
# Pop
p = [math.sin(2 * math.pi * (200 + 500 * math.exp(-k / SR * 30)) * k / SR) * math.exp(-k / SR * 18) for k in range(int(SR * 0.25))]
save("sfx/pop.wav", p)
print("audio listo")
