"""data/video.json -> voz (edge-tts) + tiempos por palabra -> public/timeline.json
Uso:  python3 scripts/pipeline.py          (con voz)
      python3 scripts/pipeline.py --dry    (sin voz, solo vista previa)"""
import asyncio, json, sys, pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
DRY = "--dry" in sys.argv
data = json.loads((ROOT / "data/video.json").read_text(encoding="utf-8"))
(ROOT / "public/voice").mkdir(parents=True, exist_ok=True)

def spread(text, duration):
    """Reparte palabras proporcionalmente a su longitud (respaldo)."""
    ws = text.split()
    total = sum(len(w) + 2 for w in ws)
    t, out = 0.0, []
    for w in ws:
        d = duration * (len(w) + 2) / total
        out.append({"text": w, "start": round(t, 3), "end": round(t + d, 3)})
        t += d
    return out

async def tts(text, path, voice, rate):
    import edge_tts
    try:
        com = edge_tts.Communicate(text, voice, rate=rate, boundary="WordBoundary")
    except TypeError:
        com = edge_tts.Communicate(text, voice, rate=rate)
    words = []
    with open(path, "wb") as f:
        async for ch in com.stream():
            if ch["type"] == "audio":
                f.write(ch["data"])
            elif ch["type"] == "WordBoundary":
                words.append({"text": ch["text"], "start": ch["offset"] / 1e7,
                              "end": (ch["offset"] + ch["duration"]) / 1e7})
    return words

async def main():
    scenes = []
    for i, sc in enumerate(data["scenes"]):
        text = sc["text"]
        if DRY:
            dur, words, audio = len(text.split()) * 0.38 + 0.4, [], None
            words = spread(text, dur)
        else:
            from mutagen.mp3 import MP3
            rel = f"voice/scene-{i}.mp3"
            words = await tts(text, ROOT / "public" / rel, data.get("voice", "es-MX-DaliaNeural"), data.get("rate", "+0%"))
            dur = MP3(ROOT / "public" / rel).info.length + 0.3
            if len(words) < len(text.split()) * 0.6:
                words = spread(text, dur - 0.3)
            audio = rel
            print(f"escena {i}: {dur:.1f}s")
        scenes.append({**sc, "audio": audio, "duration": round(dur, 3), "words": words})
    out = {"title": data["title"], "music": "music.wav", "scenes": scenes}
    (ROOT / "public/timeline.json").write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print("timeline.json listo, total aprox", round(sum(s["duration"] for s in scenes), 1), "s")

asyncio.run(main())
