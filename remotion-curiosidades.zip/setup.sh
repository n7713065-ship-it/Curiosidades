#!/bin/bash
# Instala todo lo necesario en Codespaces / Ubuntu
sudo apt-get update -y
sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libasound2t64 libxrandr2 libxkbcommon-dev \
  libxfixes3 libxcomposite1 libxdamage1 libgbm-dev libatk-bridge2.0-0 libcups2 fonts-noto-color-emoji || \
sudo apt-get install -y libasound2 fonts-noto-color-emoji
pip install --user edge-tts mutagen
npm install
python3 scripts/make_audio.py
python3 scripts/pipeline.py --dry
echo "Listo. Ejecuta: npm run studio"
